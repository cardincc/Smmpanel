<?php
$url = $_SERVER["SERVER_NAME"];  
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://localhost');
define('STYLESHEETS_URL', '//localhost' );
date_default_timezone_set('Asia/Kolkata');
error_reporting(0);
return [
  'db' => [
    'name'    =>  'profelar_db' ,
    'host'    =>  'localhost',
    'user'    =>  'profelar_db' ,
    'pass'    =>  'profelar_db' ,
    'charset' =>  'utf8mb4' 
  ]
];
?>